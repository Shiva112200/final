package com.ecommerce.app.service;

import com.ecommerce.app.entity.Product;
import com.ecommerce.app.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepository repo;

    // Add Product
    public Product addProduct(Product product) {
        return repo.save(product);
    }

    // Update Product
    public Product updateProduct(Long id, Product updatedProduct) {
        Product product = repo.findById(id).orElseThrow();

        product.setName(updatedProduct.getName());
        product.setDescription(updatedProduct.getDescription());
        product.setPrice(updatedProduct.getPrice());
        product.setStockQuantity(updatedProduct.getStockQuantity());

        return repo.save(product);
    }

    // Get Product
    public Product getProduct(Long id) {
        return repo.findById(id).orElseThrow();
    }

    // Get All
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    // Delete
    public void deleteProduct(Long id) {
        repo.deleteById(id);
    }
}