package com.ecommerce.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommerce.app.entity.User;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

	// Custom query (for login)
	Optional<User> findByUsername(String username);
	
}