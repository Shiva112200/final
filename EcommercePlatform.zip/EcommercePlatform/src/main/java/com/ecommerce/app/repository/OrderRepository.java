package com.ecommerce.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ecommerce.app.entity.Order;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {

	// Get orders of a specific user
	List<Order> findByUser_UserId(Long userId);
}
