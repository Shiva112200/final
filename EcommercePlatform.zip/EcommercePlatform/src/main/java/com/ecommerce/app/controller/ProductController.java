package com.ecommerce.app.controller;

import com.ecommerce.app.config.JwtFilter;
import com.ecommerce.app.entity.Product;
import com.ecommerce.app.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
@CrossOrigin("*")
public class ProductController {

	@Autowired
	private ProductService service;
   
	// Add product
	@PostMapping
	public Product addProduct(@RequestBody Product product) {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.addProduct(product);
	}

	// Update product
	@PutMapping("/{id}")
	public Product updateProduct(@PathVariable Long id, @RequestBody Product product) {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.updateProduct(id, product);
	}

	// Get product by ID
	@GetMapping("/{id}")
	public Product getProduct(@PathVariable Long id) {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		return service.getProduct(id);
	}

	// Get all products
	@GetMapping
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}

	// Delete
	@DeleteMapping("/{id}")
	public String deleteProduct(@PathVariable Long id) {

		if (!JwtFilter.currentRole.equals("ADMIN")) {
			throw new RuntimeException("Only ADMIN can add product");
		}

		service.deleteProduct(id);
		return "Product deleted successfully";
	}
}