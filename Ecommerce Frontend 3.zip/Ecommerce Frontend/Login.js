const form = document.getElementById("loginForm");
const togglePassword = document.getElementById("togglePassword");
const password = document.getElementById("password");
const darkToggle = document.getElementById("darkModeToggle");


togglePassword.addEventListener("click", () => {
    password.type = password.type === "password" ? "text" : "password";
    togglePassword.classList.toggle("fa-eye-slash");
});


darkToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");
});

function parseJwt(token) {
    let base64Url = token.split('.')[1];
    let base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    let jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
}


form.addEventListener("submit", async function (e) {
    e.preventDefault();

    let valid = true;

    const username = document.getElementById("username").value.trim();
    const passwordVal = password.value.trim();
    const selectedRole = document.getElementById("role").value;

    document.getElementById("userError").innerText = "";
    document.getElementById("passError").innerText = "";
    document.getElementById("roleError").innerText = "";

    if (!username) {
        document.getElementById("userError").innerText = "Username required";
        valid = false;
    }

    if (!passwordVal) {
        document.getElementById("passError").innerText = "Password required";
        valid = false;
    }

    if (!selectedRole) {
        document.getElementById("roleError").innerText = "Select role";
        valid = false;
    }

    if (!valid) return;

    try {
        const response = await fetch("http://localhost:8085/users/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username,
                password: passwordVal
            })
        });

        if (!response.ok) {
            throw new Error("Invalid credentials");
        }

        const token = await response.text();

        // Save token
        const decoded = parseJwt(token);
        const role = decoded.role;
        const userId=decoded.sub;


        localStorage.setItem("token", token);
        // localStorage.setItem("role", role);
         localStorage.setItem("userId", userId);


        // Role check
        if (role !== selectedRole) {

            Swal.fire({
                icon: "error",
                title: "Role Mismatch",
                text: "Invalid username or password",
                confirmButtonColor: "#667eea"
            });

            return;
        }



        Swal.fire({
            icon: "success",
            title: "Login Successful",
            text: "Welcome " + role,
            timer: 1500,
            showConfirmButton: false
        }).then(() => {
            if (role === "ADMIN") {
                window.location.href = "admin.html";
            } else {
                window.location.href = "customer.html";
            }
        });


    } catch (error) {

        Swal.fire({
            icon: "error",
            title: "Login Failed",
            text: "Invalid username or password",
            confirmButtonColor: "#667eea"
        });

    }
});