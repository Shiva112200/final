// ✅ BASE URL (optional, if using APIs)
const BASE_URL = "http://localhost:8085";

// ✅ Navigation Function
function goPage(page) {

    switch (page) {

        case "dashboard":
            window.location.href = "admin.html";
            break;

        case "categories":
            window.location.href = "categories.html";
            break;

        case "products":
            window.location.href = "admin-products.html";
            break;

        case "orders":
            window.location.href = "orders.html";
            break;


        case "cart":
            window.location.href = "cart.html"; // if needed
            break;

        default:
            window.location.href = "admin.html";
    }
}

// ✅ Shortcut Functions (Optional)
function goDashboard() {
    goPage("dashboard");
}

function goCategories() {
    goPage("categories");
}

function goProducts() {
    goPage("products");
}

function goOrders() {
    goPage("orders");
}

function goCart() {
    goPage("cart");
}

// ✅ Logout
function logout() {
    localStorage.clear();
    alert("Logged out successfully ✅");
    window.location.href = "login.html";
}

// ✅ Auto Redirect if Not Logged In
(function checkLogin() {
    const token = localStorage.getItem("token");

    if (!token) {
        alert("Please login first!");
        window.location.href = "login.html";
    }
})();