const form = document.getElementById("signupForm");
const togglePassword = document.getElementById("togglePassword");
const password = document.getElementById("password");

/* Show / Hide Password */
togglePassword.addEventListener("click", () => {
    password.type = password.type === "password" ? "text" : "password";
    togglePassword.classList.toggle("fa-eye-slash");
});

/* Submit */
form.addEventListener("submit", async function(e) {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const passwordVal = password.value.trim();

    // Reset errors
    document.getElementById("userError").innerText = "";
    document.getElementById("emailError").innerText = "";
    document.getElementById("passError").innerText = "";

    // ✅ Validation
    if (!username) {
        document.getElementById("userError").innerText = "Username required";
        return;
    }

    if (!email) {
        document.getElementById("emailError").innerText = "Email required";
        return;
    }

    if (!passwordVal) {
        document.getElementById("passError").innerText = "Password required";
        return;
    }

    try {

        const response = await fetch("http://localhost:8085/users/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username,
                email: email,
                password: passwordVal
                // ✅ role NOT sent (backend sets CUSTOMER)
            })
        });

        if (!response.ok) {
            const text = await response.text();
            throw new Error(text);
        }

        Swal.fire({
            icon: "success",
            title: "Signup Successful 🎉",
            text: "You can now login",
            confirmButtonColor: "#667eea"
        }).then(() => {
            window.location.href = "Login.html";
        });

    } catch (error) {

        Swal.fire({
            icon: "error",
            title: "Signup Failed ❌",
            text: "User Already exit",
            confirmButtonColor: "#667eea"
        });
    }
});